Lucas Pickering and Chris Che

Baseline Miami is a Hotline Miami-inspired baseball game. Your goal is to kill all of the fielders
with your ball. This game was made in Unity. Some of the Unity features we worked with are:
Sounds/Audio
Collision Detection/Rigid Bodies
Coroutines
Animations
Sprites & Texturing

How to Play
Wait for the automatic pitcher to shoot a ball, then click to swing. Adjust the timing of your
swing to direct the ball at the fielders. Once you kill all 6 fielders, you win!
